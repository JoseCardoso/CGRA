#ifndef MYTABLE_H
#define MYTABLE_H

#include "CGFobject.h"
#include "myUnitCube.h"
#include "myTable.h"


class myTable: public CGFobject {
 public:
  void draw();
};

#endif